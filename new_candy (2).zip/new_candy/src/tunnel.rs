//! Tunnel state machine and manager.
//!
//! A [`Tunnel`] represents a single logical bidirectional stream between client
//! and server. It owns an [`SrArq`] and a [`CongestionControl`] instance.
//!
//! [`TunnelManager`] multiplexes/demultiplexes packets across all active tunnels
//! (keyed by `tunnel_id`), drives ARQ/CC, and provides the async interface used
//! by both the client (SOCKS5) and server (TCP proxy) code.

use std::net::Ipv4Addr;
use std::sync::Arc;
use std::time::{Duration, Instant};

use anyhow::{anyhow, bail, Result};
use bytes::Bytes;
use dashmap::DashMap;
use tokio::sync::{mpsc, Mutex, Notify};

use crate::arq::{SrArq, MAX_WINDOW};
use crate::congestion::CongestionControl;
use crate::config::Config;
use crate::packet::{CandyPacket, PacketKind};
use crate::raw_socket::{OutPacket, RawSender};

const HEARTBEAT_IDLE_TIMEOUT: Duration = Duration::from_secs(5);
const HEARTBEAT_MIN_INTERVAL: Duration = Duration::from_secs(2);

// ── Tunnel state ──────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TunnelState {
    SynSent,
    SynReceived,
    Established,
    Closing,
    Closed,
}

/// Internal state for a single tunnel.
struct Tunnel {
    id:                  u32,
    state:               TunnelState,
    arq:                 SrArq,
    cc:                  CongestionControl,
    app_tx:              mpsc::Sender<Bytes>,
    last_active:         Instant,
    last_heartbeat_sent: Instant,
    window_notify:       Arc<Notify>,
    established_notify:  Arc<Notify>,
}

impl Tunnel {
    fn new(
        id:           u32,
        state:        TunnelState,
        init_seq:     u32,
        init_recv:    u32,
        app_tx:       mpsc::Sender<Bytes>,
        initial_cwnd: f64,
    ) -> Self {
        Self {
            id,
            state,
            arq:         SrArq::new(init_seq, init_recv),
            cc:          CongestionControl::new(initial_cwnd),
            app_tx,
            last_active: Instant::now(),
            last_heartbeat_sent: Instant::now(),
            window_notify:      Arc::new(Notify::new()),
            established_notify: Arc::new(Notify::new()),
        }
    }

    fn touch(&mut self) {
        self.last_active = Instant::now();
    }

    fn is_idle(&self, timeout: Duration) -> bool {
        Instant::now().duration_since(self.last_active) > timeout
    }

    fn can_send(&self) -> bool {
        self.arq.can_send() && self.arq.in_flight() < self.cc.effective_window()
    }

    fn record_rtt(&mut self, rtt_ms: f64) {
        self.cc.on_ack(Some(rtt_ms));
        self.arq.update_rto(self.cc.rtt.rto);
    }

    fn on_loss(&mut self) {
        self.cc.on_timeout();
        self.arq.update_rto(self.cc.rtt.rto);
    }

    fn apply_syn_ack(&mut self, syn_ack: &CandyPacket) -> bool {
        if self.state != TunnelState::SynSent {
            return false;
        }
        self.arq.set_recv_base(syn_ack.seq.wrapping_add(1));
        self.arq.set_send_window(syn_ack.window as u32);
        self.state = TunnelState::Established;
        true
    }

    fn make_data_packet(&mut self, payload: Bytes) -> CandyPacket {
        const UNASSIGNED_SEQ: u32 = u32::MAX;
        let ack = self.arq.recv_base();
        let window = (MAX_WINDOW.saturating_sub(self.arq.in_flight())) as u16;
        let mut pkt = CandyPacket::new_data(self.id, UNASSIGNED_SEQ, ack, window, payload);
        let _seq = self.arq.enqueue(&mut pkt);
        pkt
    }
}

// ── Remote addressing ─────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct PeerAddr {
    pub local_spoof: Ipv4Addr,
    pub peer_real:   Ipv4Addr,
    pub data_port:   u16,
    pub icmp_id:     u16,
    pub is_server:   bool,
}

// ── TunnelManager ─────────────────────────────────────────────────────────────

struct Inner {
    tunnels:               DashMap<u32, Arc<Mutex<Tunnel>>>,
    established_notifiers: DashMap<u32, Arc<Notify>>,

    /// Fixed pool of long-lived tunnels for high concurrency (client only)
    pool:       DashMap<u32, ()>,
    pool_index: std::sync::atomic::AtomicUsize,

    sender: RawSender,
    addr:   PeerAddr,
    cfg:    Arc<Config>,
}

#[derive(Clone)]
pub struct TunnelManager(Arc<Inner>);

impl TunnelManager {
    pub fn new(sender: RawSender, addr: PeerAddr, cfg: Arc<Config>) -> Self {
        Self(Arc::new(Inner {
            tunnels: DashMap::new(),
            established_notifiers: DashMap::new(),
            pool: DashMap::new(),
            pool_index: std::sync::atomic::AtomicUsize::new(0),
            sender,
            addr,
            cfg,
        }))
    }

    // ── Tunnel lifecycle ──────────────────────────────────────────────────────

    /// Open a new client-side tunnel (legacy - not used when pool is active)
    pub async fn open_tunnel(&self) -> Result<(u32, mpsc::Receiver<Bytes>, mpsc::Sender<Bytes>)> {
        let id: u32 = rand::random();
        let syn_seq: u32 = rand::random();

        let (app_tx, app_rx) = mpsc::channel::<Bytes>(1024);
        let (net_tx, net_rx) = mpsc::channel::<Bytes>(1024);

        let tunnel = Tunnel::new(
            id,
            TunnelState::SynSent,
            syn_seq.wrapping_add(1),
            0,
            app_tx,
            self.0.cfg.initial_cwnd,
        );

        let window_notify = tunnel.window_notify.clone();
        let established_notify = tunnel.established_notify.clone();

        self.0.tunnels.insert(id, Arc::new(Mutex::new(tunnel)));
        self.spawn_send_task(id, net_rx, window_notify);

        let syn = CandyPacket::new_syn(id, syn_seq);
        self.tx_control(syn).await?;

        log::info!("tunnel {} opened (SYN sent)", id);
        self.0.established_notifiers.insert(id, established_notify);

        Ok((id, app_rx, net_tx))
    }

    /// Accept an incoming SYN packet (server side)
    pub async fn accept_syn(
        &self,
        syn: CandyPacket,
        src_ip: Ipv4Addr,
    ) -> Result<(u32, mpsc::Receiver<Bytes>, mpsc::Sender<Bytes>)> {
        let id = syn.tunnel_id;

        if self.0.tunnels.contains_key(&id) {
            bail!("duplicate tunnel id {}", id);
        }

        let our_seq: u32 = rand::random();
        let (app_tx, app_rx) = mpsc::channel::<Bytes>(1024);
        let (net_tx, net_rx) = mpsc::channel::<Bytes>(1024);

        let mut tunnel = Tunnel::new(
            id,
            TunnelState::SynReceived,
            our_seq.wrapping_add(1),
            syn.seq.wrapping_add(1),
            app_tx,
            self.0.cfg.initial_cwnd,
        );

        tunnel.state = TunnelState::Established;
        let window_notify = tunnel.window_notify.clone();

        self.0.tunnels.insert(id, Arc::new(Mutex::new(tunnel)));
        self.spawn_send_task(id, net_rx, window_notify);

        let syn_ack = CandyPacket::new_syn_ack(id, syn.seq, our_seq);
        self.tx_control(syn_ack).await?;

        log::info!("tunnel {} accepted from {}", id, src_ip);
        Ok((id, app_rx, net_tx))
    }

    /// Close a tunnel and notify the peer.
    pub async fn close_tunnel(&self, id: u32) {
        if let Some((_, t)) = self.0.tunnels.remove(&id) {
            let mut t = t.lock().await;
            t.state = TunnelState::Closed;
        }
        self.0.established_notifiers.remove(&id);

        let fin = CandyPacket::new_fin(id);
        let _ = self.tx_control(fin).await;
    }

    // ── Incoming packet handler ───────────────────────────────────────────────

    pub async fn handle_incoming(
        &self,
        src_ip: Ipv4Addr,
        pkt: CandyPacket,
    ) -> Result<Option<(CandyPacket, Ipv4Addr)>> {
        if pkt.kind == PacketKind::Syn {
            return Ok(Some((pkt, src_ip)));
        }

        let tunnel = match self.0.tunnels.get(&pkt.tunnel_id) {
            Some(t) => t.clone(),
            None => {
                log::trace!("received packet for unknown tunnel {} from {}", pkt.tunnel_id, src_ip);
                return Ok(None);
            }
        };

        let mut t = tunnel.lock().await;
        t.touch();

        match pkt.kind {
            PacketKind::Syn => unreachable!(),

            PacketKind::SynAck => {
                if t.apply_syn_ack(&pkt) {
                    log::info!("tunnel {} established", pkt.tunnel_id);
                    let tid = t.id;
                    let notify = t.established_notify.clone();
                    let wnotify = t.window_notify.clone();
                    let ack = CandyPacket::new_ack(tid, pkt.seq.wrapping_add(1), MAX_WINDOW as u16);
                    drop(t);

                    notify.notify_waiters();
                    wnotify.notify_waiters();
                    self.tx_control(ack).await?;
                }
            }

            PacketKind::Ack => {
                let acked = t.arq.process_ack(pkt.ack);
                t.arq.set_send_window(pkt.window as u32);
                if acked.is_empty() {
                    t.cc.on_duplicate_ack();
                } else {
                    t.cc.on_ack(None);
                }
                t.window_notify.notify_one();
            }

            PacketKind::Nack => {
                if let Some(retransmit) = t.arq.process_nack(pkt.seq) {
                    drop(t);
                    self.tx_data(retransmit).await?;
                    return Ok(None);
                }
            }

            PacketKind::Data => {
                let tid = t.id;
                let app_tx = t.app_tx.clone();
                let (deliverable, ack_num, nacks) = t.arq.receive(pkt.clone());
                let window = (MAX_WINDOW.saturating_sub(t.arq.in_flight())) as u16;
                drop(t);

                for payload in deliverable {
                    if app_tx.send(payload).await.is_err() {
                        self.close_tunnel(tid).await;
                        return Ok(None);
                    }
                }

                self.tx_control(CandyPacket::new_ack(tid, ack_num, window)).await?;
                for missing in nacks {
                    self.tx_control(CandyPacket::new_nack(tid, missing)).await?;
                }
            }

            PacketKind::Fin => {
                t.state = TunnelState::Closed;
                log::info!("tunnel {} closed by peer", pkt.tunnel_id);
            }

            PacketKind::Heartbeat => {
                let tid = t.id;
                let hb_ack = CandyPacket {
                    kind:      PacketKind::HeartbeatAck,
                    tunnel_id: tid,
                    seq:       pkt.seq,
                    ack:       0,
                    window:    0,
                    payload:   pkt.payload,
                };
                drop(t);
                self.tx_control(hb_ack).await?;
            }

            PacketKind::HeartbeatAck => {
                if pkt.payload.len() >= 8 {
                    let sent_ms = u64::from_be_bytes(pkt.payload[..8].try_into().unwrap_or([0u8; 8])) as f64;
                    let now_ms = std::time::SystemTime::now()
                        .duration_since(std::time::UNIX_EPOCH)
                        .unwrap_or_default()
                        .as_millis() as f64;
                    let rtt = (now_ms - sent_ms).max(0.0);
                    t.record_rtt(rtt);
                    log::debug!("tunnel {} RTT {:.1} ms", pkt.tunnel_id, rtt);
                }
            }
        }

        Ok(None)
    }

    // ── Periodic tick ─────────────────────────────────────────────────────────

    pub async fn tick(&self) -> Result<()> {
        let (expired_pkts, heartbeats, _to_remove): (Vec<_>, Vec<_>, Vec<_>) = {
            let mut exp = Vec::new();
            let mut hbs = Vec::new();
            let mut dead = Vec::new();
            let now = Instant::now();

            let tunnels: Vec<(u32, Arc<Mutex<Tunnel>>)> = self
                .0
                .tunnels
                .iter()
                .map(|entry| (*entry.key(), entry.value().clone()))
                .collect();

            for (id, tunnel) in tunnels {
                let mut t = tunnel.lock().await;

                if t.state == TunnelState::Closed {
                    dead.push(id);
                    continue;
                }

                let timed_out = t.arq.take_timed_out();
                if !timed_out.is_empty() {
                    t.on_loss();
                    exp.extend(timed_out);
                }

                if t.state == TunnelState::Established
                    && t.is_idle(HEARTBEAT_IDLE_TIMEOUT)
                    && now.duration_since(t.last_heartbeat_sent) >= HEARTBEAT_MIN_INTERVAL
                {
                    t.last_heartbeat_sent = now;
                    hbs.push(CandyPacket::new_heartbeat(t.id, rand::random()));
                }
            }

            for id in &dead {
                self.0.tunnels.remove(id);
                self.0.established_notifiers.remove(id);
            }
            (exp, hbs, dead)
        };

        for pkt in expired_pkts {
            self.tx_data(pkt).await?;
        }
        for hb in heartbeats {
            self.tx_control(hb).await?;
        }
        Ok(())
    }

    // ── Status helpers ────────────────────────────────────────────────────────

    pub async fn wait_established(&self, id: u32, timeout: Duration) -> bool {
        if self.is_established(id).await {
            return true;
        }

        let notifier = self.0.established_notifiers.get(&id).map(|n| n.clone());
        let Some(notifier) = notifier else { return false; };

        let established = tokio::time::timeout(timeout, notifier.notified())
            .await
            .is_ok()
            && self.is_established(id).await;

        if established {
            self.0.established_notifiers.remove(&id);
        }
        established
    }

    pub async fn is_established(&self, id: u32) -> bool {
        let Some(tunnel) = self.0.tunnels.get(&id).map(|t| t.clone()) else {
            return false;
        };
        let guard = tunnel.lock().await;
        guard.state == TunnelState::Established
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    fn spawn_send_task(
        &self,
        tunnel_id: u32,
        mut net_rx: mpsc::Receiver<Bytes>,
        window_notify: Arc<Notify>,
    ) {
        let this = self.clone();
        let mtu = self.0.cfg.mtu;

        tokio::spawn(async move {
            while let Some(data) = net_rx.recv().await {
                let mut offset = 0;
                while offset < data.len() {
                    let end = (offset + mtu).min(data.len());
                    let chunk = data.slice(offset..end);

                    loop {
                        let can = {
                            if let Some(tunnel) = this.0.tunnels.get(&tunnel_id).map(|t| t.clone()) {
                                tunnel.lock().await.can_send()
                            } else {
                                false
                            }
                        };
                        if can {
                            break;
                        }
                        window_notify.notified().await;
                    }

                    if let Err(e) = this.enqueue_and_send(tunnel_id, chunk).await {
                        log::debug!("send task tunnel {}: {}", tunnel_id, e);
                        return;
                    }
                    offset = end;
                }
            }
            log::debug!("send task for tunnel {} finished", tunnel_id);
        });
    }

    async fn enqueue_and_send(&self, tunnel_id: u32, payload: Bytes) -> Result<()> {
        let pkt = {
            let tunnel = self
                .0
                .tunnels
                .get(&tunnel_id)
                .map(|t| t.clone())
                .ok_or_else(|| anyhow!("tunnel {} gone", tunnel_id))?;
            let mut t = tunnel.lock().await;
            t.make_data_packet(payload)
        };
        self.tx_data(pkt).await
    }

    async fn tx_control(&self, pkt: CandyPacket) -> Result<()> {
        let a = &self.0.addr;
        let enc = pkt.encode();
        let out = OutPacket::Icmp {
            src_ip: a.local_spoof,
            dst_ip: a.peer_real,
            id: a.icmp_id,
            seq: (pkt.seq & 0xffff) as u16,
            payload: enc,
        };
        self.0.sender.send(out).await
    }

    async fn tx_data(&self, pkt: CandyPacket) -> Result<()> {
        let a = &self.0.addr;
        let enc = pkt.encode();
        let out = OutPacket::Udp {
            src_ip: a.local_spoof,
            dst_ip: a.peer_real,
            src_port: a.data_port,
            dst_port: a.data_port,
            payload: enc,
        };
        self.0.sender.send(out).await
    }

    // ── Tunnel Pool ───────────────────────────────────────────────────────────

    /// Initialize a fixed pool of long-lived tunnels (only called on client).
    pub async fn init_tunnel_pool(&self) -> Result<()> {
        let count = self.0.cfg.tunnel_count;
        if count == 0 {
            bail!("tunnel_count must be at least 1");
        }

        log::info!("Initializing tunnel pool with {} tunnels...", count);

        for _ in 0..count {
            let id: u32 = rand::random();
            let syn_seq: u32 = rand::random();

            let (app_tx, _app_rx) = mpsc::channel::<Bytes>(2048);
            let tunnel = Tunnel::new(
                id,
                TunnelState::SynSent,
                syn_seq.wrapping_add(1),
                0,
                app_tx,
                self.0.cfg.initial_cwnd,
            );

            let window_notify = tunnel.window_notify.clone();
            let established_notify = tunnel.established_notify.clone();

            self.0.tunnels.insert(id, Arc::new(Mutex::new(tunnel)));
            self.0.established_notifiers.insert(id, established_notify.clone());
            self.0.pool.insert(id, ());

            let syn = CandyPacket::new_syn(id, syn_seq);
            self.tx_control(syn).await?;

            if tokio::time::timeout(Duration::from_secs(12), established_notify.notified())
                .await
                .is_err()
            {
                bail!("Tunnel pool initialization timed out for tunnel {}", id);
            }

            log::debug!("Tunnel {} added to pool", id);
        }

        log::info!("✅ Tunnel pool of {} tunnels is ready", count);
        Ok(())
    }

    /// Get a tunnel from the pool using round-robin (used by SOCKS5)
    pub async fn get_pooled_tunnel(&self) -> Result<(u32, mpsc::Receiver<Bytes>, mpsc::Sender<Bytes>)> {
        let pool_size = self.0.pool.len();
        if pool_size == 0 {
            bail!("Tunnel pool is empty - call init_tunnel_pool first");
        }

        let idx = self.0.pool_index.fetch_add(1, std::sync::atomic::Ordering::Relaxed) % pool_size;
        let tunnel_ids: Vec<u32> = self.0.pool.iter().map(|e| *e.key()).collect();
        let tunnel_id = tunnel_ids[idx];

        let (app_tx, app_rx) = mpsc::channel::<Bytes>(2048);
        let (net_tx, net_rx) = mpsc::channel::<Bytes>(2048);

        if let Some(tun) = self.0.tunnels.get(&tunnel_id) {
            let window_notify = {
                let guard = tun.value().lock().await;
                guard.window_notify.clone()
            };
            self.spawn_send_task(tunnel_id, net_rx, window_notify);
        } else {
            bail!("Tunnel {} disappeared from pool", tunnel_id);
        }

        Ok((tunnel_id, app_rx, net_tx))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use bytes::Bytes;

    #[tokio::test]
    async fn client_syn_ack_updates_recv_base_to_peer_seq_plus_one() {
        const PEER_SEQ: u32 = 777;
        let (app_tx, _app_rx) = mpsc::channel::<Bytes>(1);
        let mut tunnel = Tunnel::new(1, TunnelState::SynSent, 100, 0, app_tx, 10.0);
        let syn_ack = CandyPacket::new_syn_ack(1, 99, PEER_SEQ);

        assert_eq!(tunnel.arq.recv_base(), 0);
        assert!(tunnel.apply_syn_ack(&syn_ack));
        assert_eq!(tunnel.arq.recv_base(), PEER_SEQ + 1);
    }

    #[tokio::test]
    async fn make_data_packet_uses_arq_assigned_seq() {
        let (app_tx, _app_rx) = mpsc::channel::<Bytes>(1);
        let mut tunnel = Tunnel::new(42, TunnelState::Established, 1000, 7, app_tx, 10.0);

        let p1 = tunnel.make_data_packet(Bytes::from_static(b"a"));
        let p2 = tunnel.make_data_packet(Bytes::from_static(b"b"));

        assert_eq!(p1.seq, 1000);
        assert_eq!(p2.seq, 1001);
        assert_eq!(p1.ack, 7);
        assert_eq!(p2.ack, 7);
    }
}