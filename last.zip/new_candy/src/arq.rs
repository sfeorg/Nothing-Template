//! Optimized Selective Repeat ARQ (SrArq)
//! 
//! این نسخه از Ring Buffer برای مدیریت پنجره ارسال و دریافت استفاده می‌کند
//! تا تخصیص حافظه (Allocation) در ترافیک بالا به حداقل برسد.

use std::collections::VecDeque;
use std::time::{Duration, Instant};
use bytes::Bytes;
use crate::packet::CandyPacket;

/// حداکثر اندازه پنجره برای جلوگیری از پر شدن حافظه
pub const MAX_WINDOW: u32 = 2048;
const INITIAL_RTO: Duration = Duration::from_millis(200);
const MIN_RTO: Duration = Duration::from_millis(50);
const MAX_RTO: Duration = Duration::from_secs(3);

#[derive(Clone)]
struct SentPacket {
    pkt: CandyPacket,
    sent_at: Instant,
    retries: u32,
}

pub struct SrArq {
    // --- Sending State ---
    send_base: u32,
    next_seq: u32,
    send_window: u32,
    // استفاده از آرایه ثابت برای سرعت O(1)
    send_buffer: Vec<Option<SentPacket>>,
    
    // --- Receiving State ---
    pub recv_base: u32,
    // بافر دریافت برای پکت‌های خارج از ترتیب
    recv_buffer: Vec<Option<CandyPacket>>,
    
    // --- Retransmission Logic ---
    rto: Duration,
    last_nack_at: Instant,
}

impl SrArq {
    pub fn new(init_send_seq: u32, init_recv_seq: u32) -> Self {
        Self {
            send_base: init_send_seq,
            next_seq: init_send_seq,
            send_window: 64, // مقدار اولیه کوچک، توسط CC مدیریت می‌شود
            send_buffer: vec![None; MAX_WINDOW as usize],
            
            recv_base: init_recv_seq,
            recv_buffer: vec![None; MAX_WINDOW as usize],
            
            rto: INITIAL_RTO,
            last_nack_at: Instant::now(),
        }
    }

    // --- Sending Logic ---

    pub fn can_send(&self) -> bool {
        let distance = self.next_seq.wrapping_sub(self.send_base);
        distance < self.send_window && distance < MAX_WINDOW
    }

    pub fn in_flight(&self) -> u32 {
        self.next_seq.wrapping_sub(self.send_base)
    }

    pub fn enqueue(&mut self, pkt: &mut CandyPacket) -> u32 {
        let seq = self.next_seq;
        pkt.seq = seq;
        
        let idx = (seq % MAX_WINDOW) as usize;
        self.send_buffer[idx] = Some(SentPacket {
            pkt: pkt.clone(),
            sent_at: Instant::now(),
            retries: 0,
        });
        
        self.next_seq = self.next_seq.wrapping_add(1);
        seq
    }

    pub fn process_ack(&mut self, ack_seq: u32) -> Vec<u32> {
        let mut acked_indices = Vec::new();
        
        // در Selective Repeat، پکت‌های قبل از ACK لزوماً تایید شده نیستند
        // اما ما فرض می‌کنیم ACK به معنای تایید تا آن شماره است (Cumulative ACK)
        while self.send_base != ack_seq && self.send_base.wrapping_sub(ack_seq) as i32 < 0 {
            let idx = (self.send_base % MAX_WINDOW) as usize;
            if self.send_buffer[idx].is_some() {
                self.send_buffer[idx] = None;
                acked_indices.push(self.send_base);
            }
            self.send_base = self.send_base.wrapping_add(1);
        }
        acked_indices
    }

    pub fn process_nack(&mut self, nack_seq: u32) -> Option<CandyPacket> {
        let idx = (nack_seq % MAX_WINDOW) as usize;
        if let Some(ref mut sent) = self.send_buffer[idx] {
            if sent.pkt.seq == nack_seq {
                sent.sent_at = Instant::now();
                sent.retries += 1;
                return Some(sent.pkt.clone());
            }
        }
        None
    }

    // --- Receiving Logic ---

    pub fn receive(&mut self, pkt: CandyPacket) -> (Vec<Bytes>, u32, Vec<u32>) {
        let seq = pkt.seq;
        let mut deliverable = Vec::new();
        let mut nacks = Vec::new();

        // اگر پکت تکراری یا خیلی قدیمی باشد
        if seq.wrapping_sub(self.recv_base) as i32 < 0 {
            return (deliverable, self.recv_base, nacks);
        }

        // ذخیره در بافر دریافت
        let idx = (seq % MAX_WINDOW) as usize;
        if seq.wrapping_sub(self.recv_base) < MAX_WINDOW {
            if self.recv_buffer[idx].is_none() {
                self.recv_buffer[idx] = Some(pkt);
            }
        }

        // استخراج پکت‌های مرتب شده برای تحویل به اپلیکیشن
        while let Some(p) = self.recv_buffer[(self.recv_base % MAX_WINDOW) as usize].take() {
            deliverable.push(p.payload);
            self.recv_base = self.recv_base.wrapping_add(1);
        }

        // تولید NACK هوشمند: فقط اگر زمان کافی از آخرین NACK گذشته باشد
        if self.last_nack_at.elapsed() > Duration::from_millis(10) {
            let mut check_seq = self.recv_base;
            // بررسی گپ‌ها در بافر برای حداکثر ۳۲ پکت بعدی
            for _ in 0..32 {
                let c_idx = (check_seq % MAX_WINDOW) as usize;
                if self.recv_buffer[c_idx].is_none() {
                    nacks.push(check_seq);
                }
                check_seq = check_seq.wrapping_add(1);
                if check_seq.wrapping_sub(self.recv_base) >= 128 { break; }
            }
            if !nacks.is_empty() {
                self.last_nack_at = Instant::now();
            }
        }

        (deliverable, self.recv_base, nacks)
    }

    // --- Retransmission Timer ---

    pub fn take_timed_out(&mut self) -> Vec<CandyPacket> {
        let mut timed_out = Vec::new();
        let now = Instant::now();
        
        // فقط پکت‌های موجود در پنجره فعلی را چک کن
        let mut check_seq = self.send_base;
        while check_seq != self.next_seq {
            let idx = (check_seq % MAX_WINDOW) as usize;
            if let Some(ref mut sent) = self.send_buffer[idx] {
                if now.duration_since(sent.sent_at) > self.rto {
                    sent.sent_at = now;
                    sent.retries += 1;
                    timed_out.push(sent.pkt.clone());
                }
            }
            check_seq = check_seq.wrapping_add(1);
        }
        timed_out
    }

    // --- Helpers ---

    pub fn update_rto(&mut self, new_rto: f64) {
        self.rto = Duration::from_secs_f64(new_rto / 1000.0)
            .clamp(MIN_RTO, MAX_RTO);
    }

    pub fn set_send_window(&mut self, window: u32) {
        self.send_window = window.clamp(1, MAX_WINDOW);
    }

    pub fn set_recv_base(&mut self, seq: u32) {
        self.recv_base = seq;
    }

    pub fn recv_base(&self) -> u32 {
        self.recv_base
    }
}