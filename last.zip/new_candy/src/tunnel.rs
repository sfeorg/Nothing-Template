//! Tunnel Management & Coordination
//! 
//! این فایل تمام قطعات (ARQ, CC, RawSocket) را برای ایجاد یک ارتباط پایدار به هم متصل می‌کند.

use std::net::Ipv4Addr;
use std::sync::Arc;
use dashmap::DashMap;
use tokio::sync::{mpsc, Mutex};
use anyhow::{Result, anyhow};
use bytes::Bytes;

use crate::config::Config;
use crate::packet::{CandyPacket, PacketKind};
use crate::arq::SrArq;
use crate::congestion::CongestionControl;
use crate::raw_socket::{RawSender, OutPacket};

/// آدرس‌دهی جفت‌های تونل
#[derive(Clone, Debug)]
pub struct PeerAddr {
    pub local_spoof: Ipv4Addr,
    pub peer_real: Ipv4Addr,
    pub data_port: u16,
    pub icmp_id: u16,
    pub is_server: bool,
}

/// ساختار داخلی هر تونل
struct TunnelState {
    arq: SrArq,
    cc: CongestionControl,
    app_tx: mpsc::Sender<Bytes>,
    last_activity: std::time::Instant,
}

#[derive(Clone)]
pub struct TunnelManager {
    inner: Arc<TunnelManagerInner>,
}

struct TunnelManagerInner {
    sender: RawSender,
    peer_addr: PeerAddr,
    cfg: Arc<Config>,
    // استفاده از DashMap برای حذف Mutex سراسری و افزایش سرعت
    tunnels: DashMap<u32, Mutex<TunnelState>>,
    // استخر تونل‌های آماده برای کلاینت
    pool: Mutex<Vec<u32>>,
}

impl TunnelManager {
    pub fn new(sender: RawSender, peer_addr: PeerAddr, cfg: Arc<Config>) -> Self {
        Self {
            inner: Arc::new(TunnelManagerInner {
                sender,
                peer_addr,
                cfg,
                tunnels: DashMap::new(),
                pool: Mutex::new(Vec::new()),
            }),
        }
    }

    /// کلاینت: ایجاد استخر تونل‌های آماده برای کاهش تاخیر SOCKS5
    pub async fn init_tunnel_pool(&self) -> Result<()> {
        for i in 0..self.inner.cfg.tunnel_count {
            let tid = (i + 1) as u32;
            let (app_tx, _) = mpsc::channel(1024); // موقت
            
            let state = TunnelState {
                arq: SrArq::new(100, 100),
                cc: CongestionControl::new(self.inner.cfg.initial_cwnd),
                app_tx,
                last_activity: std::time::Instant::now(),
            };
            
            self.inner.tunnels.insert(tid, Mutex::new(state));
            
            // ارسال پکت SYN برای باز کردن تونل در سمت سرور
            let syn = CandyPacket::new_syn(tid, 100);
            self.send_to_net(syn).await?;
            
            self.inner.pool.lock().await.push(tid);
        }
        Ok(())
    }

    /// SOCKS5: دریافت یک تونل آزاد از استخر
    pub async fn open_tunnel_from_pool(&self, target_meta: &str) -> Result<(u32, mpsc::Receiver<Bytes>, mpsc::Sender<Bytes>)> {
        let mut pool = self.inner.pool.lock().await;
        let tid = pool.pop().ok_or_else(|| anyhow!("No available tunnels in pool"))?;
        
        let (app_tx, app_rx) = mpsc::channel(2048);
        let (net_tx, mut net_rx) = mpsc::channel::<Bytes>(2048);

        // بروزرسانی کانال‌های ارتباطی تونل
        if let Some(mut state_lock) = self.inner.tunnels.get_mut(&tid) {
            let state = state_lock.get_mut();
            state.app_tx = app_tx;
        }

        // ارسال متادیتای CONNECT (مقصد نهایی)
        let connect_msg = format!("CONNECT {}", target_meta);
        let mut first_pkt = CandyPacket::new_data(tid, 0, 0, 0, Bytes::from(connect_msg));
        
        // ترد مدیریت ارسال دیتا برای این تونل خاص
        let self_clone = self.clone();
        tokio::spawn(async move {
            self_clone.send_data_loop(tid, first_pkt, net_rx).await;
        });

        Ok((tid, app_rx, net_tx))
    }

    /// سرور: پذیرش درخواست تونل جدید
    pub async fn accept_syn(&self, syn: CandyPacket, src_ip: Ipv4Addr) -> Result<(u32, mpsc::Receiver<Bytes>, mpsc::Sender<Bytes>)> {
        let tid = syn.tunnel_id;
        let (app_tx, app_rx) = mpsc::channel(2048);
        let (net_tx, net_rx) = mpsc::channel::<Bytes>(2048);

        let state = TunnelState {
            arq: SrArq::new(syn.seq, syn.seq),
            cc: CongestionControl::new(self.inner.cfg.initial_cwnd),
            app_tx,
            last_activity: std::time::Instant::now(),
        };

        self.inner.tunnels.insert(tid, Mutex::new(state));

        // پاسخ SYN-ACK
        let syn_ack = CandyPacket::new_syn_ack(tid, syn.seq, 100);
        self.send_to_net(syn_ack).await?;

        let self_clone = self.clone();
        tokio::spawn(async move {
            self_clone.send_data_loop(tid, CandyPacket::new_ack(tid, 0, 0), net_rx).await;
        });

        Ok((tid, app_rx, net_tx))
    }

    /// هسته اصلی پردازش پکت‌های ورودی از شبکه
    pub async fn handle_incoming(&self, src_ip: Ipv4Addr, pkt: CandyPacket) -> Result<Option<(CandyPacket, Ipv4Addr)>> {
        if pkt.kind == PacketKind::Syn && self.inner.peer_addr.is_server {
            return Ok(Some((pkt, src_ip)));
        }

        if let Some(state_mutex) = self.inner.tunnels.get(&pkt.tunnel_id) {
            let mut state = state_mutex.lock().await;
            state.last_activity = std::time::Instant::now();

            match pkt.kind {
                PacketKind::Ack => {
                    let acked = state.arq.process_ack(pkt.ack);
                    if !acked.is_empty() {
                        state.cc.on_ack(None); // در نسخه پیشرفته RTT اینجا محاسبه می‌شود
                    }
                }
                PacketKind::Nack => {
                    if let Some(re_pkt) = state.arq.process_nack(pkt.seq) {
                        self.send_to_net(re_pkt).await?;
                        state.cc.on_duplicate_ack();
                    }
                }
                PacketKind::Data => {
                    let (payloads, next_ack, nacks) = state.arq.receive(pkt);
                    
                    // ارسال دیتا به اپلیکیشن (SOCKS5/TCP)
                    for data in payloads {
                        let _ = state.app_tx.send(data).await;
                    }

                    // ارسال ACK فورا برای تداوم جریان
                    let ack_pkt = CandyPacket::new_ack(pkt.tunnel_id, next_ack, state.cc.effective_window() as u16);
                    self.send_to_net(ack_pkt).await?;

                    // ارسال NACKها در صورت وجود گپ
                    for nseq in nacks {
                        let nack_pkt = CandyPacket::new_nack(pkt.tunnel_id, nseq);
                        self.send_to_net(nack_pkt).await?;
                    }
                }
                _ => {}
            }
        }
        Ok(None)
    }

    /// حلقه اختصاصی هر تونل برای خرد کردن دیتا و ارسال با رعایت CWND
    async fn send_data_loop(&self, tid: u32, mut initial_pkt: CandyPacket, mut net_rx: mpsc::Receiver<Bytes>) {
        // اگر پکت اولیه وجود داشت (مثل CONNECT یا ACK) بفرست
        if initial_pkt.kind == PacketKind::Data {
            let _ = self.enqueue_and_send(tid, &mut initial_pkt).await;
        }

        while let Some(data) = net_rx.recv().await {
            // خرد کردن دیتا بر اساس MSS برای جلوگیری از Fragmentation
            for chunk in data.chunks(self.inner.cfg.effective_mss()) {
                let mut pkt = CandyPacket::new_data(tid, 0, 0, 0, Bytes::copy_from_slice(chunk));
                
                // صبر کن تا پنجره ازدحام اجازه ارسال بدهد
                loop {
                    let can_send = {
                        if let Some(state) = self.inner.tunnels.get(&tid) {
                            let s = state.lock().await;
                            s.arq.can_send()
                        } else { false }
                    };

                    if can_send { break; }
                    tokio::time::sleep(std::time::Duration::from_millis(5)).await;
                }

                let _ = self.enqueue_and_send(tid, &mut pkt).await;
            }
        }
    }

    async fn enqueue_and_send(&self, tid: u32, pkt: &mut CandyPacket) -> Result<()> {
        if let Some(state_mutex) = self.inner.tunnels.get(&tid) {
            let mut state = state_mutex.lock().await;
            state.arq.enqueue(pkt);
            self.send_to_net(pkt.clone()).await?;
        }
        Ok(())
    }

    /// ارسال فیزیکی پکت روی شبکه (انتخاب بین UDP و ICMP)
    async fn send_to_net(&self, pkt: CandyPacket) -> Result<()> {
        let payload = pkt.encode();
        let out = if pkt.tunnel_id % 2 == 0 {
            OutPacket::Udp {
                src_ip: self.inner.peer_addr.local_spoof,
                dst_ip: self.inner.peer_addr.peer_real,
                src_port: self.inner.cfg.data_port,
                dst_port: self.inner.cfg.data_port,
                payload,
            }
        } else {
            OutPacket::Icmp {
                src_ip: self.inner.peer_addr.local_spoof,
                dst_ip: self.inner.peer_addr.peer_real,
                id: self.inner.peer_addr.icmp_id,
                seq: (pkt.seq % 65535) as u16,
                payload,
            }
        };
        self.inner.sender.send(out).await
    }

    /// مدیریت تایمرها و ریتنسمیت‌ها (تیک ۱۰۰ میلی‌ثانیه‌ای)
    pub async fn tick(&self) -> Result<()> {
        for mut entry in self.inner.tunnels.iter_mut() {
            let mut state = entry.lock().await;
            
            // بررسی تایم‌اوت‌های ARQ
            let timed_out = state.arq.take_timed_out();
            if !timed_out.is_empty() {
                state.cc.on_timeout();
                for pkt in timed_out {
                    self.send_to_net(pkt).await?;
                }
            }
        }
        Ok(())
    }

    pub async fn close_tunnel(&self, tid: u32) {
        if let Some(state) = self.inner.tunnels.get(&tid) {
            let _ = self.send_to_net(CandyPacket::new_fin(tid)).await;
        }
        self.inner.tunnels.remove(&tid);
    }
}