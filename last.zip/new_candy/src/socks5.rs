//! SOCKS5 Proxy Server Implementation
//! 
//! این فایل مسئول پذیرش اتصالات SOCKS5 و پل زدن آن‌ها به تونل‌های Candy-Spoof است.

use std::sync::Arc;
use tokio::net::{TcpListener, TcpStream};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use anyhow::{Context, Result, anyhow};

use crate::config::Config;
use crate::tunnel::TunnelManager;

/// نقطه ورود اصلی برای اجرای سرور SOCKS5
pub async fn run_socks5(cfg: Arc<Config>, manager: TunnelManager) -> Result<()> {
    let addr = format!("127.0.0.1:{}", cfg.socks5_port);
    let listener = TcpListener::bind(&addr).await
        .with_context(|| format!("Failed to bind SOCKS5 to {}", addr))?;

    log::info!("SOCKS5 proxy listening on {}", addr);

    loop {
        let (socket, peer) = listener.accept().await?;
        log::debug!("New SOCKS5 connection from {}", peer);

        let mgr = manager.clone();
        let config = cfg.clone();

        tokio::spawn(async move {
            if let Err(e) = handle_socks5_client(socket, config, mgr).await {
                log::warn!("SOCKS5 client error: {}", e);
            }
        });
    }
}

async fn handle_socks5_client(mut stream: TcpStream, cfg: Arc<Config>, manager: TunnelManager) -> Result<()> {
    // 1. Greeting & Authentication Selection
    let mut header = [0u8; 2];
    stream.read_exact(&mut header).await?;
    
    if header[0] != 0x05 {
        return Err(anyhow!("Only SOCKS5 is supported"));
    }

    let n_methods = header[1] as usize;
    let mut methods = vec![0u8; n_methods];
    stream.read_exact(&mut methods).await?;

    // NO AUTHENTICATION REQUIRED (0x00)
    stream.write_all(&[0x05, 0x00]).await?;

    // 2. Request Handling
    let mut request_head = [0u8; 4];
    stream.read_exact(&mut request_head).await?;

    if request_head[1] != 0x01 { // Only CONNECT command
        return Err(anyhow!("Unsupported SOCKS5 command"));
    }

    // Parse Target Address
    let target_host = match request_head[3] {
        0x01 => { // IPv4
            let mut addr = [0u8; 4];
            stream.read_exact(&mut addr).await?;
            std::net::Ipv4Addr::from(addr).to_string()
        }
        0x03 => { // Domain Name
            let len = stream.read_u8().await? as usize;
            let mut domain = vec![0u8; len];
            stream.read_exact(&mut domain).await?;
            String::from_utf8_lossy(&domain).to_string()
        }
        _ => return Err(anyhow!("Unsupported address type")),
    };

    let target_port = stream.read_u16().await?;
    let target_addr = format!("{}:{}", target_host, target_port);

    // 3. ایجاد تونل جدید از طریق TunnelManager
    // ما از یک تونل آماده در Pool استفاده می‌کنیم تا تاخیر به حداقل برسد.
    let (tunnel_id, mut app_rx, net_tx) = manager.open_tunnel_from_pool(&target_addr).await
        .context("Failed to get tunnel from pool")?;

    // ارسال پاسخ موفقیت به کلاینت SOCKS5
    // BND.ADDR (4 bytes) + BND.PORT (2 bytes) -> zeros
    stream.write_all(&[0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await?;

    log::info!("SOCKS5: [Tunnel {}] Proxying to {}", tunnel_id, target_addr);

    // 4. پل زدن دیتا (Bidirectional Relay)
    let (mut tcp_read, mut tcp_write) = stream.into_split();

    // Task: SOCKS5 -> Tunnel
    let t1 = tokio::spawn(async move {
        let mut buf = vec![0u8; cfg.effective_mss()];
        loop {
            match tcp_read.read(&mut buf).await {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if net_tx.send(bytes::Bytes::copy_from_slice(&buf[..n])).await.is_err() {
                        break;
                    }
                }
            }
        }
    });

    // Task: Tunnel -> SOCKS5
    let t2 = tokio::spawn(async move {
        while let Some(data) = app_rx.recv().await {
            if tcp_write.write_all(&data).await.is_err() {
                break;
            }
        }
    });

    // منتظر بمان تا یکی از طرفین اتصال را قطع کند
    tokio::select! {
        _ = t1 => {},
        _ = t2 => {},
    }

    manager.close_tunnel(tunnel_id).await;
    log::debug!("SOCKS5: Tunnel {} closed", tunnel_id);

    Ok(())
}