//! Congestion Control Logic (AIMD Based)
//! 
//! این فایل مسئول مدیریت پنجره ارسال و تخمین سرعت شبکه (RTT) است.

use std::time::{Duration, Instant};

const MIN_CWND: f64 = 2.0;
const MAX_CWND: f64 = 1024.0;

/// مدیریت تخمین زمان رفت و برگشت پکت‌ها
pub struct RttEstimator {
    pub srtt: f64,   // Smoothed RTT
    pub rttvar: f64, // RTT Variation
    pub rto: f64,    // Retransmission Timeout
}

impl RttEstimator {
    pub fn new() -> Self {
        Self {
            srtt: 200.0,  // شروع با 200 میلی‌ثانیه
            rttvar: 50.0,
            rto: 300.0,
        }
    }

    /// (RFC 6298) بروزرسانی مقادیر بر اساس اندازه‌گیری جدید
    pub fn update(&mut self, measured_rtt: f64) {
        let alpha = 0.125;
        let beta = 0.25;

        self.rttvar = (1.0 - beta) * self.rttvar + beta * (self.srtt - measured_rtt).abs();
        self.srtt = (1.0 - alpha) * self.srtt + alpha * measured_rtt;
        self.rto = (self.srtt + 4.0 * self.rttvar).clamp(50.0, 3000.0);
    }
}

/// کنترل‌کننده اصلی ازدحام
pub struct CongestionControl {
    pub cwnd: f64,          // پنجره فعلی (تعداد پکت)
    pub ssthresh: f64,      // آستانه شروع آهسته
    pub rtt: RttEstimator,
    last_update: Instant,
}

impl CongestionControl {
    pub fn new(initial_cwnd: f64) -> Self {
        Self {
            cwnd: initial_cwnd.clamp(MIN_CWND, MAX_CWND),
            ssthresh: 64.0,
            rtt: RttEstimator::new(),
            last_update: Instant::now(),
        }
    }

    /// زمانی فراخوانی می‌شود که یک پکت با موفقیت ACK شود
    pub fn on_ack(&mut self, measured_rtt: Option<f64>) {
        if let Some(rtt_val) = measured_rtt {
            self.rtt.update(rtt_val);
        }

        // AIMD Logic
        if self.cwnd < self.ssthresh {
            // Slow Start: افزایش نمایی
            self.cwnd += 1.0;
        } else {
            // Congestion Avoidance: افزایش خطی
            self.cwnd += 1.0 / self.cwnd.floor();
        }

        self.cwnd = self.cwnd.min(MAX_CWND);
        self.last_update = Instant::now();
    }

    /// زمانی فراخوانی می‌شود که پکت تایم‌اوت شود (نشانه ازدحام)
    pub fn on_timeout(&mut self) {
        // Multiplicative Decrease
        self.ssthresh = (self.cwnd / 2.0).max(MIN_CWND);
        self.cwnd = MIN_CWND; // بازگشت به شروع آهسته
        
        // RTO Backoff
        self.rtt.rto = (self.rtt.rto * 1.5).min(5000.0);
        self.last_update = Instant::now();
    }

    /// زمانی فراخوانی می‌شود که پکت مفقودی (NACK) گزارش شود
    pub fn on_duplicate_ack(&mut self) {
        // Fast Recovery سبک
        self.cwnd = (self.cwnd * 0.8).max(MIN_CWND);
        self.ssthresh = self.cwnd;
    }

    /// مقدار موثر پنجره برای لایه ARQ
    pub fn effective_window(&self) -> u32 {
        self.cwnd.floor() as u32
    }
}