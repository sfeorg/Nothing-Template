//! Raw Socket Manager for IP Spoofing
//! 
//! این فایل مسئول ارسال و دریافت پکت‌ها در سطح لایه ۳ (IP) است.
//! از AF_PACKET در لینوکس برای دور زدن استک شبکه استفاده می‌شود.

use std::net::Ipv4Addr;
use std::sync::Arc;
use anyhow::{bail, Result};
use bytes::{Bytes, BytesMut, BufMut};
use tokio::sync::mpsc;

use crate::packet::CandyPacket;

#[derive(Debug, Clone)]
pub enum OutPacket {
    Udp {
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        src_port: u16,
        dst_port: u16,
        payload: Bytes,
    },
    Icmp {
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        id: u16,
        seq: u16,
        payload: Bytes,
    },
}

pub struct IncomingPacket {
    pub src_ip: Ipv4Addr,
    pub pkt: CandyPacket,
}

#[derive(Clone)]
pub struct RawSender {
    tx: mpsc::Sender<OutPacket>,
}

impl RawSender {
    pub fn spawn() -> Result<Self> {
        let (tx, mut rx) = mpsc::channel::<OutPacket>(2048);
        
        // ترد اختصاصی برای ارسال پکت‌ها (به دلیل استفاده از Raw Sockets)
        std::thread::spawn(move || {
            let socket = socket2::Socket::new(
                socket2::Domain::IPV4,
                socket2::Type::RAW,
                Some(socket2::Protocol::UDP), // ما از RAW استفاده می‌کنیم اما برای ارسال دیتا
            ).expect("Failed to create raw send socket");

            socket.set_header_included(true).expect("Failed to set IP_HDRINCL");

            while let Some(out) = rx.blocking_recv() {
                let _ = match out {
                    OutPacket::Udp { src_ip, dst_ip, src_port, dst_port, payload } => {
                        let full_pkt = build_udp_ip_packet(src_ip, dst_ip, src_port, dst_port, &payload);
                        let dest = std::net::SocketAddr::new(std::net::IpAddr::V4(dst_ip), 0);
                        socket.send_to(&full_pkt, &dest.into())
                    }
                    OutPacket::Icmp { src_ip, dst_ip, id, seq, payload } => {
                        let full_pkt = build_icmp_ip_packet(src_ip, dst_ip, id, seq, &payload);
                        let dest = std::net::SocketAddr::new(std::net::IpAddr::V4(dst_ip), 0);
                        socket.send_to(&full_pkt, &dest.into())
                    }
                };
            }
        });

        Ok(Self { tx })
    }

    pub async fn send(&self, pkt: OutPacket) -> Result<()> {
        self.tx.send(pkt).await.map_err(|_| anyhow::anyhow!("Send channel closed"))
    }
}

pub struct RawReceiver {
    rx: mpsc::Receiver<IncomingPacket>,
}

impl RawReceiver {
    pub fn spawn(data_port: u16, icmp_id: u16, allowed_ips: Vec<Ipv4Addr>) -> Result<Self> {
        let (tx, rx) = mpsc::channel::<IncomingPacket>(2048);

        std::thread::spawn(move || {
            let socket = socket2::Socket::new(
                socket2::Domain::IPV4,
                socket2::Type::RAW,
                Some(socket2::Protocol::ICMPV4),
            ).expect("Failed to create raw recv socket");

            let mut buf = vec![0u8; 2048];
            loop {
                if let Ok((n, _addr)) = socket.recv_from(buf.as_mut_slice()) {
                    let data = &buf[..n];
                    if data.len() < 20 { continue; } // IP Header size

                    let src_ip = Ipv4Addr::new(data[12], data[13], data[14], data[15]);
                    
                    // فیلتر کردن بر اساس لیست سفید برای امنیت و پرفورمنس
                    if !allowed_ips.contains(&src_ip) { continue; }

                    let ip_hdr_len = (data[0] & 0x0F) as usize * 4;
                    if let Some(candy) = CandyPacket::decode(&data[ip_hdr_len..]) {
                        let _ = tx.blocking_send(IncomingPacket { src_ip, pkt: candy });
                    }
                }
            }
        });

        Ok(Self { rx })
    }

    pub async fn recv(&mut self) -> Option<IncomingPacket> {
        self.rx.recv().await
    }
}

// --- Helper Functions for Checksum and Header Building ---

fn build_udp_ip_packet(src: Ipv4Addr, dst: Ipv4Addr, src_port: u16, dst_port: u16, payload: &[u8]) -> Vec<u8> {
    let mut pkt = BytesMut::with_capacity(20 + 8 + payload.len());
    
    // IP Header (20 bytes)
    pkt.put_u8(0x45); // Version 4, Length 5
    pkt.put_u8(0);    // ToS
    pkt.put_u16(20 + 8 + payload.len() as u16); // Total Len
    pkt.put_u16(rand::random()); // ID
    pkt.put_u16(0);   // Flags & Offset
    pkt.put_u8(64);   // TTL
    pkt.put_u8(17);   // Protocol (UDP)
    pkt.put_u16(0);   // Checksum (Kernel will fill this if IP_HDRINCL is handled)
    pkt.put(src.octets().as_ref());
    pkt.put(dst.octets().as_ref());

    // UDP Header (8 bytes)
    pkt.put_u16(src_port);
    pkt.put_u16(dst_port);
    pkt.put_u16(8 + payload.len() as u16);
    pkt.put_u16(0); // Optional Checksum
    pkt.put(payload);

    pkt.to_vec()
}

fn build_icmp_ip_packet(src: Ipv4Addr, dst: Ipv4Addr, id: u16, seq: u16, payload: &[u8]) -> Vec<u8> {
    let mut pkt = BytesMut::with_capacity(20 + 8 + payload.len());
    
    // IP Header
    pkt.put_u8(0x45);
    pkt.put_u8(0);
    pkt.put_u16(20 + 8 + payload.len() as u16);
    pkt.put_u16(rand::random());
    pkt.put_u16(0);
    pkt.put_u8(64);
    pkt.put_u8(1); // Protocol (ICMP)
    pkt.put_u16(0);
    pkt.put(src.octets().as_ref());
    pkt.put(dst.octets().as_ref());

    // ICMP Echo Header
    let mut icmp = BytesMut::with_capacity(8 + payload.len());
    icmp.put_u8(8); // Type (Echo Request)
    icmp.put_u8(0); // Code
    icmp.put_u16(0); // Checksum Placeholder
    icmp.put_u16(id);
    icmp.put_u16(seq);
    icmp.put(payload);

    let cksum = calculate_checksum(&icmp);
    icmp[2] = (cksum >> 8) as u8;
    icmp[3] = (cksum & 0xff) as u8;

    pkt.put(icmp);
    pkt.to_vec()
}

fn calculate_checksum(data: &[u8]) -> u16 {
    let mut sum = 0u32;
    for i in (0..data.len()).step_by(2) {
        let word = if i + 1 < data.len() {
            u16::from_be_bytes([data[i], data[i+1]])
        } else {
            u16::from_be_bytes([data[i], 0])
        };
        sum += word as u32;
    }
    while sum >> 16 != 0 {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    !(sum as u16)
}