//! Configuration management for Candy-Spoof.
//! 
//! این نسخه شامل تمام فیلدهای لازم برای هندل کردن وضعیت‌های لایه شبکه و پراکسی است.

use std::fs;
use std::net::Ipv4Addr;
use serde::{Deserialize, Serialize};
use anyhow::{Context, Result};

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct Config {
    // --- IP Addressing ---
    /// آدرس IP واقعی این ماشین
    pub real_ip: Ipv4Addr,
    /// آدرس IP واقعی مقصد (سرور/کلاینت مقابل)
    pub peer_real_ip: Ipv4Addr,
    /// آدرس IP جعلی که ما استفاده می‌کنیم
    pub spoofed_ip: Ipv4Addr,
    /// آدرس IP جعلی که طرف مقابل استفاده می‌کند
    pub peer_spoofed_ip: Ipv4Addr,
    /// استخر آدرس‌های جعلی برای چرخش (Rotation)
    pub spoofed_ip_pool: Vec<Ipv4Addr>,

    // --- Channel Settings ---
    /// پورت UDP برای انتقال دیتا
    pub data_port: u16,
    /// شناسه ICMP برای کانال کنترل
    pub icmp_id: u16,

    // --- Security ---
    /// کلید مشترک برای احراز هویت (فعلاً به عنوان Placeholder در متادیتا)
    pub pre_shared_key: String,
    /// لیست IPهای مجاز برای ارتباط
    pub allowed_peers: Vec<Ipv4Addr>,

    // --- Performance & Tunneling ---
    /// تعداد تونل‌های موازی (Pool)
    pub tunnel_count: usize,
    /// حداکثر اندازه پکت در لایه لینک
    pub mtu: usize,
    /// پنجره ازدحام اولیه (Congestion Window)
    pub initial_cwnd: f64,

    // --- Network & Proxy ---
    /// کارت شبکه مورد نظر (eth0, tun0, ...)
    pub interface: String,
    /// پورت محلی برای SOCKS5 (فقط کلاینت)
    pub socks5_port: u16,
}

impl Config {
    /// خواندن تنظیمات از فایل و مدیریت خطاها
    pub fn from_file(path: &str) -> Result<Self> {
        let content = fs::read_to_string(path)
            .with_context(|| format!("Could not read config file: {}", path))?;
        
        let config: Config = toml::from_str(&content)
            .with_context(|| format!("Error parsing TOML in {}", path))?;
        
        Ok(config)
    }

    /// انتخاب یک IP برای جعل هویت (با اولویت استخر IPها)
    pub fn pick_spoofed_ip(&self) -> Ipv4Addr {
        if self.spoofed_ip_pool.is_empty() {
            self.spoofed_ip
        } else {
            let idx = rand::random::<usize>() % self.spoofed_ip_pool.len();
            self.spoofed_ip_pool[idx]
        }
    }

    /// محاسبه اندازه مفید دیتا برای جلوگیری از شکسته شدن پکت (MSS)
    pub fn effective_mss(&self) -> usize {
        // 20 bytes (IP) + 8 bytes (UDP/ICMP) + 12 bytes (Candy Header) = 40
        self.mtu.saturating_sub(40)
    }

    /// بررسی اعتبار IP فرستنده
    pub fn is_peer_allowed(&self, addr: &Ipv4Addr) -> bool {
        addr == &self.peer_real_ip || 
        addr == &self.peer_spoofed_ip || 
        self.allowed_peers.contains(addr)
    }
}