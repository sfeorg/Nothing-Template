//! Candy-Spoof Packet Protocol
//! 
//! این فایل ساختار باینری پکت‌ها را تعریف می‌کند.
//! ساختار پکت:
//! [0..1] Kind | [1..5] Tunnel ID | [5..9] Seq | [9..13] Ack | [13..15] Window | [15..] Payload

use bytes::{BufMut, Bytes, BytesMut};
use byteorder::{BigEndian, ByteOrder};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum PacketKind {
    Syn = 1,
    SynAck = 2,
    Ack = 3,
    Nack = 4,
    Data = 5,
    Fin = 6,
    Heartbeat = 7,
    HeartbeatAck = 8,
}

impl PacketKind {
    pub fn from_u8(v: u8) -> Self {
        match v {
            1 => Self::Syn,
            2 => Self::SynAck,
            3 => Self::Ack,
            4 => Self::Nack,
            5 => Self::Data,
            6 => Self::Fin,
            7 => Self::Heartbeat,
            8 => Self::HeartbeatAck,
            _ => Self::Data, // Default
        }
    }
}

#[derive(Debug, Clone)]
pub struct CandyPacket {
    pub kind: PacketKind,
    pub tunnel_id: u32,
    pub seq: u32,
    pub ack: u32,
    pub window: u16,
    pub payload: Bytes,
}

impl CandyPacket {
    const HEADER_SIZE: usize = 15;

    pub fn new_data(tid: u32, seq: u32, ack: u32, win: u16, payload: Bytes) -> Self {
        Self { kind: PacketKind::Data, tunnel_id: tid, seq, ack, window: win, payload }
    }

    pub fn new_syn(tid: u32, seq: u32) -> Self {
        Self { kind: PacketKind::Syn, tunnel_id: tid, seq, ack: 0, window: 0, payload: Bytes::new() }
    }

    pub fn new_syn_ack(tid: u32, ack: u32, seq: u32) -> Self {
        Self { kind: PacketKind::SynAck, tunnel_id: tid, seq, ack, window: 0, payload: Bytes::new() }
    }

    pub fn new_ack(tid: u32, ack: u32, win: u16) -> Self {
        Self { kind: PacketKind::Ack, tunnel_id: tid, seq: 0, ack, window: win, payload: Bytes::new() }
    }

    pub fn new_nack(tid: u32, seq: u32) -> Self {
        Self { kind: PacketKind::Nack, tunnel_id: tid, seq, ack: 0, window: 0, payload: Bytes::new() }
    }

    pub fn new_fin(tid: u32) -> Self {
        Self { kind: PacketKind::Fin, tunnel_id: tid, seq: 0, ack: 0, window: 0, payload: Bytes::new() }
    }

    pub fn new_heartbeat(tid: u32, timestamp: u64) -> Self {
        let mut b = BytesMut::with_capacity(8);
        b.put_u64(timestamp);
        Self { kind: PacketKind::Heartbeat, tunnel_id: tid, seq: 0, ack: 0, window: 0, payload: b.freeze() }
    }

    /// تبدیل ساختار به باینری برای ارسال روی شبکه
    pub fn encode(&self) -> Bytes {
        let mut buf = BytesMut::with_capacity(Self::HEADER_SIZE + self.payload.len());
        buf.put_u8(self.kind as u8);
        buf.put_u32(self.tunnel_id);
        buf.put_u32(self.seq);
        buf.put_u32(self.ack);
        buf.put_u16(self.window);
        buf.put(&self.payload[..]);
        buf.freeze()
    }

    /// تبدیل باینری دریافتی از شبکه به ساختار پکت
    pub fn decode(data: &[u8]) -> Option<Self> {
        if data.len() < Self::HEADER_SIZE { return None; }

        let kind = PacketKind::from_u8(data[0]);
        let tunnel_id = BigEndian::read_u32(&data[1..5]);
        let seq = BigEndian::read_u32(&data[5..9]);
        let ack = BigEndian::read_u32(&data[9..13]);
        let window = BigEndian::read_u16(&data[13..15]);
        let payload = Bytes::copy_from_slice(&data[15..]);

        Some(Self { kind, tunnel_id, seq, ack, window, payload })
    }
}